robot( virtual, "8999" ).     %%the port is the default used by clientWenvObjTcp.kt
%%robot( realmbot, "COM6" ).  %% /dev/ttyUSB0
%% robot( realnano, "" ).
