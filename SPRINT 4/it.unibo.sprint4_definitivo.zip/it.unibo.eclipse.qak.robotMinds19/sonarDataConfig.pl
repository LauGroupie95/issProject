/*
CONFIGURATION PARAMS FOR THE sonar PIPE
*/
limitDistance(12).
minDistance( 2 ).
maxDistance( 50 ).
maxDelta( 1 ).	 %% maxDelta( 0 ). FOR VIRTUAL ROBOT
amplif( 8	).   %%%sonar data amplification for the radar, that does D/3
 