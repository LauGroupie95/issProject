import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.After
import org.junit.Before
import org.junit.Test
import kotlinx.coroutines.*
import it.unibo.kactor.*
import alice.tuprolog.*
import kotlin.random.Random
import org.junit.runners.MethodSorters
import org.junit.FixMethodOrder
import java.io.BufferedReader
import java.io.FileReader

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
class testPrepare {
	
	var robotPositionX = "0"
	var robotPositionY = "0"
	
	var p = mutableListOf<String>("dishes","forks","glasses")
	var d = mutableListOf<String>()
	var f = mutableListOf<String>("c000,raspberry,5", "c001,meat,5", "c002,cola,5", "c003,salad,5", "c004,pizza,10", "c005,fanta,10", "c006,apple,10")
	var ot = mutableListOf<String>()
	var ft = mutableListOf<String>()
	var or = mutableListOf<String>()
	var fr = mutableListOf<String>()
	
	/**
	 * Test plan:
     * 1) da RH a dispensa
	 */
	@Test
	fun a_moveToPantry(){
		println("\n-------- TestPrepare moveToPantry --------\n")
		val positions = utils.readGoalCoord_FileLog("pantry")	
  		println("positions = $positions")
		
		val listOperations = utils.readLogPrepare("PANTRY")
		println("listOperations = $listOperations")
		
		for(op in listOperations){
			//op = (-, PA, dishes)
			if(op.first == '-' && op.second == "PA"){
				p.remove(op.third)
			} else if (op.first == '+' && op.second == "OR"){
				or.add(op.third)
			}
		}
		
		assertTrue("", positions.first == 0 && positions.second == 4 && p.isEmpty() && (!or.isEmpty() && or.size == 3))
	}
	
	@Test
	fun b_moveToTableFromPantry(){
		println("\n-------- TestPrepare moveToTableFromPantry --------\n")
		
		val positions = utils.readGoalCoord_FileLog("table", 1) //1 perch� � la prima volta che va al tavolo
  		println("positions = $positions")
		
		val listOperations = utils.readLogPrepare("TABLE", 1)
		println("listOperations = $listOperations")
		
		for(op in listOperations){
			//op = (+, OT, dishes)
			if(op.first == '-' && op.second == "OR"){
				or.remove(op.third)
			} else if (op.first == '+' && op.second == "OT"){
				ot.add(op.third)
			}
		}
		
		assertTrue("", positions.first == 4 && positions.second == 4 && or.isEmpty() && (!ot.isEmpty() && ot.size == 3))
	}
	
	@Test
	fun c_moveToFridge(){
		println("\n-------- TestPrepare moveToFridge --------\n")
		
		val positions = utils.readGoalCoord_FileLog("fridge")	
  		println("positions = $positions")
		
		val listOperations = utils.readLogPrepare("FRIDGE")
		println("listOperations = $listOperations")
		
		for(op in listOperations){
			//op = (-, FD, c001,meat,5)
			if(op.first == '-' && op.second == "FD"){
				f.remove(op.third)
			} else if (op.first == '+' && op.second == "FR"){
				fr.add(op.third)
			}
		}
		
		assertTrue("", positions.first == 6 && positions.second == 0 && f.size == 4 && (!fr.isEmpty() && fr.size == 3))
	}
	
	@Test
	fun d_moveToTableFromFridge(){
		println("\n-------- TestPrepare moveToTableFromFridge --------\n")
		
		val positions = utils.readGoalCoord_FileLog("table", 2) //2 perch� � la seconda volta che va al tavolo
  		println("positions = $positions")
		
		val listOperations = utils.readLogPrepare("TABLE", 2)
		println("listOperations = $listOperations")
		
		for(op in listOperations){
			//op = (+, FT, c001,meat,5)
			if(op.first == '-' && op.second == "FR"){
				fr.remove(op.third)
			} else if (op.first == '+' && op.second == "FT"){
				ft.add(op.third)
			}
		}
		
		assertTrue("", positions.first == 5 && positions.second == 1 && fr.isEmpty() && (!ft.isEmpty() && ft.size == 3))
	}

	@Test
	fun e_returnHome(){
		println("\n-------- TestPrepare returnHome --------\n")
		
		val positions = utils.readGoalCoord_FileLog("RH")	
  		println("positions = $positions")
		
		assertTrue("", positions.first == 0 && positions.second == 0)
	}
	
	/*
 	 * Mappa della stanza
     *    0  1  2  3  4  5  6  7
 	 * 0 |r, 1, 1, 1, 1, 1, F, X, 
	 * 1 |1, 0, 0, 0, 0, 0, 1, X, 
	 * 2 |1, 0, 0, T, T, 0, 1, X, 
	 * 3 |1, 0, 0, T, T, 0, 1, X, 
	 * 4 |P, 1, 1, 1, 1, 1, D, X, 
	 * 5 |X, X, X, X, X, X, X, X,
 	 */
	
}