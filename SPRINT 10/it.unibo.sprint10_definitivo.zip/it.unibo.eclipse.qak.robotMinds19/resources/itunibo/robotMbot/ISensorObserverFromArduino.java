package itunibo.robotMbot;

public interface ISensorObserverFromArduino {
	public void notify(String data);
}
