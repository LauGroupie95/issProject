package itunibo.robotMbot;
import it.unibo.is.interfaces.protocols.IConnInteraction;

public interface ISerialPortInteraction extends IConnInteraction{
}
